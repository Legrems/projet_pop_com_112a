#ifndef ENUM_H
#define ENUM_H

enum Error {FILENAME_NONE,  READ_OPEN,
    	    LECTURE_ETAT,   MODE_NONE,
            ERROR_NONE,     NBCELL_0,
            NBPLAYERS_0,    NBOBSTACLE_0,
            NBBALLS_0,
            UNKNOWN_ERROR,  UNKNOWN_FORMAT};
            



#endif
